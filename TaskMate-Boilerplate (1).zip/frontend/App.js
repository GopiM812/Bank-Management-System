
// === Frontend (React.js) ===

// App.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');

  useEffect(() => {
    axios.get('http://localhost:5000/tasks').then((response) => setTasks(response.data));
  }, []);

  const addTask = () => {
    axios.post('http://localhost:5000/tasks', { title: newTask }).then(() => {
      setNewTask('');
      axios.get('http://localhost:5000/tasks').then((response) => setTasks(response.data));
    });
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4">TaskMate</h1>
      <input
        className="border p-2 w-full mb-2"
        type="text"
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
        placeholder="Add new task"
      />
      <button className="bg-blue-500 text-white p-2 w-full" onClick={addTask}>Add Task</button>
      <ul className="mt-4">
        {tasks.map((task) => (
          <li key={task.id} className="border p-2 mb-2">
            {task.title} - {task.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
