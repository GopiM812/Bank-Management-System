
-- === MySQL Database Schema ===

CREATE DATABASE taskmate;

USE taskmate;

CREATE TABLE tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  status VARCHAR(50) NOT NULL
);
