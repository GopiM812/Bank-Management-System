
// === Backend (Node.js + Express.js) ===

// server.js
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'taskmate'
});

// Basic Routes
app.get('/tasks', (req, res) => {
  db.query('SELECT * FROM tasks', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

app.post('/tasks', (req, res) => {
  const { title } = req.body;
  db.query('INSERT INTO tasks (title, status) VALUES (?, ?)', [title, 'To-Do'], (err) => {
    if (err) return res.status(500).send(err);
    res.send('Task added');
  });
});

app.listen(5000, () => console.log('Server running on port 5000'));
